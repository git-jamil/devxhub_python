# devxhub_python

A custom CLI for generating Django projects with Cookiecutter templates.

## Installation

```sh
pip install devxhub_python
```

## Usage

```sh
devxhub_python https://github.com/devxhub/django-boilerplate
```